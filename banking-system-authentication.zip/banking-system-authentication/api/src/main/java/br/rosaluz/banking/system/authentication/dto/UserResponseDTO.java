package br.rosaluz.banking.system.authentication.dto;


public class UserResponseDTO {

    public boolean isAvailable;

    public UserResponseDTO(boolean isAvailable){
              this.isAvailable = isAvailable;

    }

}
