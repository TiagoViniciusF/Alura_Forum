package br.rosaluz.banking.system.authentication.consumer.dto;

public class AccountConsumerMenssageDTO {
}
